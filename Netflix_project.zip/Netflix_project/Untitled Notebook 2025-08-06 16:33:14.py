# Databricks notebook source
from datetime import datetime

# COMMAND ----------

var = dbutils.jobs.taskValues.get(
    taskKey="ifweekday",
    key="weekoutput",
    default="Unknown",
    debugValue="Monday"   # Simulated value for interactive runs
)
print(var)


# COMMAND ----------

